<?php 
$con = mysqli_connect("localhost","root","","blog_schema");
$Name = $_POST['Name'];
$Email = $_POST['Email'];
$password = $_POST['password'];

$sql = "INSERT INTO `tbl_contact` (`Id`, `fldName`, `fldEmail`, `fldPassword`) VALUES ('0', '$Name', '$Email', '$password')";

$rs = mysqli_query($con, $sql) or die ($mysqli_error);

if($rs)
{
	echo "Contact Records Inserted";
}

$num = mysqli_numrows($rs);
if ($num > 0) {
    echo "Username already exists<br>";
} else {
        $SQL = "insert into USERS (username) values ('$username')";
        mysqli_query($sql) or die (mysqli_error($mysqli_error));
        }
        mysqli_close($mysqli);
?>