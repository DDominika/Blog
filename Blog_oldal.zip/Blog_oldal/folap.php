<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
<fieldset>
<legend>Contact Form</legend>
<form name="frmContact" method="post" action="database.php">
<p>
<label for="Name">Name </label>
<input type="text" name="Name" id="Name">
</p>
<p>
<label for="email">Email</label>
<input type="text" name="Email" id="Email">
</p>
<p>
<label for="pass">Password (8 characters minimum):</label>
<input type="password" id="password" name="password">
</p>
<p>&nbsp;</p>
<p>
<input type="submit" name="Submit" id="Submit" value="Submit">
</p>
</form>
</fieldset>
</body>
</html>